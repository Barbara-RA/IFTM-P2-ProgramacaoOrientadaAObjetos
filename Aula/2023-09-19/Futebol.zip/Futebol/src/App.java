import java.util.Scanner;

public class App {

    public static JogadorDeFutrbol leDados(){
        Scanner s = new Scanner(System.in);
        System.out.println("informe nome");
        String nome = s.nextLine();
        String posicao= s.nextLine();
        int anoNascimento= s.nextInt();
        String nacionalidade= s.nextLine();
        double altura= s.nextDouble();
        double peso= s.nextDouble();
        s.close();
        JogadorDeFutrbol jogador = new JogadorDeFutrbol(nome, posicao, anoNascimento, nacionalidade, altura, peso);
        return jogador;
    }


    public static String anoRestante(JogadorDeFutrbol jogador){
        int tempoFalta = 0;
        if(jogador.posicao.equalsIgnoreCase("atacante")|| (jogador.calculeIdade()<35)){
            tempoFalta= 35-jogador.calculeIdade();
    
        }else if(jogador.posicao.equalsIgnoreCase("defesa")|| (jogador.calculeIdade()<40)){
            tempoFalta= 40-jogador.calculeIdade();

        }else if(jogador.posicao.equalsIgnoreCase("meio campo")|| (jogador.calculeIdade()<38)){
            tempoFalta = 38-jogador.calculeIdade();
        }
        return "Faltam "+tempoFalta+" anos para o jogador "+jogador.nome+" se aposentar";  
    }


    public static void main(String[] args) throws Exception {
       JogadorDeFutrbol jogador = leDados();
       System.out.println(jogador.exibe()); 
       System.out.println(anoRestante(jogador));
    }



}
