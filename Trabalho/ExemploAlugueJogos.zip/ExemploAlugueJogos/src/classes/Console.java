package classes;

public class Console {
    private String name;

    public Console(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
