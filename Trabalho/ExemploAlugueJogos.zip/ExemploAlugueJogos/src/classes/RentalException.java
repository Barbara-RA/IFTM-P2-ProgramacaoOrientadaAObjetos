package classes;

public class RentalException extends Exception {
    public RentalException(String message) {
        super(message);
    }
}

